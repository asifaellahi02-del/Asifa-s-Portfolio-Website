
// =========================================
// ASIFA ELLAHI - PORTFOLIO JAVASCRIPT
// =========================================


// 1. MOBILE NAVIGATION

const menuToggle = document.getElementById("menuToggle");
const navLinks = document.getElementById("navLinks");

menuToggle.addEventListener("click", function () {

    navLinks.classList.toggle("active");

    const isOpen = navLinks.classList.contains("active");

    menuToggle.setAttribute("aria-expanded", isOpen);

    menuToggle.setAttribute(
        "aria-label",
        isOpen ? "Close navigation menu" : "Open navigation menu"
    );

    menuToggle.textContent = isOpen ? "✕" : "☰";

});


// 2. CLOSE MENU AFTER CLICKING A LINK

const navigationLinks = document.querySelectorAll(".nav-links a");

navigationLinks.forEach(function (link) {

    link.addEventListener("click", function () {

        navLinks.classList.remove("active");

        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation menu");

        menuToggle.textContent = "☰";

    });

});


// 3. CONTACT FORM VALIDATION

const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");

contactForm.addEventListener("submit", function (event) {

    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const subject = document.getElementById("subject").value.trim();
    const message = document.getElementById("message").value.trim();

    // Check empty fields

    if (!name || !email || !subject || !message) {

        formStatus.textContent =
            "Please complete all the fields.";

        return;
    }

    // Validate email address

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(email)) {

        formStatus.textContent =
            "Please enter a valid email address.";

        return;
    }

    // Replace with Asifa's real email address

    const receiverEmail = "your-email@example.com";

    // Prepare message details

    const emailBody =
        "Name: " + name +
        "\nEmail: " + email +
        "\n\nMessage:\n" + message;

    // Prepare email link

    const mailLink =
        "mailto:" + receiverEmail +
        "?subject=" + encodeURIComponent(subject) +
        "&body=" + encodeURIComponent(emailBody);

    formStatus.textContent =
        "Opening your email application. Please send the prepared message.";

    // Open visitor's email application

    window.location.href = mailLink;

});


// 4. AUTOMATIC COPYRIGHT YEAR

const yearElement = document.getElementById("year");

yearElement.textContent = new Date().getFullYear();


// 5. CLOSE MOBILE MENU WHEN RESIZING TO DESKTOP

window.addEventListener("resize", function () {

    if (window.innerWidth > 650) {

        navLinks.classList.remove("active");

        menuToggle.setAttribute("aria-expanded", "false");
        menuToggle.setAttribute("aria-label", "Open navigation menu");

        menuToggle.textContent = "☰";

    }

});
